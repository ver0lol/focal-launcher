package io.nekohasekai.sfa.compose

import android.Manifest
import android.annotation.SuppressLint
import android.content.ContentResolver
import android.content.Intent
import android.net.Uri
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.util.Log
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.exclude
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LinkOff
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.UnfoldLess
import androidx.compose.material.icons.filled.UnfoldMore
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScaffoldDefaults
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.adaptive.currentWindowAdaptiveInfo
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.fromHtml
import androidx.compose.ui.unit.dp
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.os.ConfigurationCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import dev.jeziellago.compose.markdowntext.MarkdownText
import io.nekohasekai.libbox.Libbox
import io.nekohasekai.sfa.Application
import io.nekohasekai.sfa.BuildConfig
import io.nekohasekai.sfa.R
import io.nekohasekai.sfa.bg.BoxService
import io.nekohasekai.sfa.bg.CrashReportManager
import io.nekohasekai.sfa.bg.OOMReportManager
import io.nekohasekai.sfa.bg.PowerReportManager
import io.nekohasekai.sfa.bg.ServiceConnection
import io.nekohasekai.sfa.bg.ServiceNotification
import io.nekohasekai.sfa.compat.WindowSizeClassCompat
import io.nekohasekai.sfa.compat.isWidthAtLeastBreakpointCompat
import io.nekohasekai.sfa.compose.base.GlobalEventBus
import io.nekohasekai.sfa.compose.base.SelectableMessageDialog
import io.nekohasekai.sfa.compose.base.UiEvent
import io.nekohasekai.sfa.compose.component.RemoteStatusBar
import io.nekohasekai.sfa.compose.component.ServiceStatusBar
import io.nekohasekai.sfa.compose.component.SnackbarHost
import io.nekohasekai.sfa.compose.component.UpdateAvailableDialog
import io.nekohasekai.sfa.compose.component.UptimeText
import io.nekohasekai.sfa.compose.model.Connection
import io.nekohasekai.sfa.compose.navigation.NavHost
import io.nekohasekai.sfa.compose.navigation.NewProfileArgs
import io.nekohasekai.sfa.compose.navigation.ProfileRoutes
import io.nekohasekai.sfa.compose.navigation.Screen
import io.nekohasekai.sfa.compose.navigation.bottomNavigationScreens
import io.nekohasekai.sfa.compose.screen.configuration.ProfileImportHandler
import io.nekohasekai.sfa.compose.screen.connections.ConnectionDetailsScreen
import io.nekohasekai.sfa.compose.screen.connections.ConnectionsPage
import io.nekohasekai.sfa.compose.screen.connections.ConnectionsViewModel
import io.nekohasekai.sfa.compose.screen.dashboard.DashboardViewModel
import io.nekohasekai.sfa.compose.screen.dashboard.GroupsCard
import io.nekohasekai.sfa.compose.screen.dashboard.groups.GroupsViewModel
import io.nekohasekai.sfa.compose.screen.log.LogViewModel
import io.nekohasekai.sfa.compose.screen.tools.OpenConnectStatusViewModel
import io.nekohasekai.sfa.compose.screen.tools.OpenVPNStatusViewModel
import io.nekohasekai.sfa.compose.screen.tools.TaildropSendManager
import io.nekohasekai.sfa.compose.screen.tools.TailscaleSSHSharedViewModel
import io.nekohasekai.sfa.compose.screen.tools.TailscaleStatusViewModel
import io.nekohasekai.sfa.compose.screen.usbip.USBIPStatusViewModel
import io.nekohasekai.sfa.compose.theme.Theme
import io.nekohasekai.sfa.compose.topbar.LocalScaffoldPadding
import io.nekohasekai.sfa.compose.topbar.LocalTopBarController
import io.nekohasekai.sfa.compose.topbar.TopBarController
import io.nekohasekai.sfa.compose.topbar.TopBarEntry
import io.nekohasekai.sfa.constant.Action
import io.nekohasekai.sfa.constant.Alert
import io.nekohasekai.sfa.constant.ServiceMode
import io.nekohasekai.sfa.constant.Status
import io.nekohasekai.sfa.database.Settings
import io.nekohasekai.sfa.ktx.hasPermission
import io.nekohasekai.sfa.ktx.launchCustomTab
import io.nekohasekai.sfa.update.UpdateState
import io.nekohasekai.sfa.utils.RemoteControlManager
import io.nekohasekai.sfa.vendor.Vendor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity :
    AppCompatActivity(),
    ServiceConnection.Callback {
    private val connection = ServiceConnection(this, this)
    private lateinit var dashboardViewModel: DashboardViewModel
    private var currentServiceStatus by mutableStateOf(Status.Stopped)
    private var currentAlert by mutableStateOf<Pair<Alert, String?>?>(null)
    private var showLocationPermissionDialog by mutableStateOf(false)
    private var showBackgroundLocationDialog by mutableStateOf(false)
    private var showLocalNetworkPermissionDialog by mutableStateOf(false)
    private var notificationPermissionRequested = false
    private var localNetworkPermissionRequested = false
    private var showImportProfileDialog by mutableStateOf(false)
    private var pendingImportProfile by mutableStateOf<Triple<String, String, String>?>(null)
    private var showImportLocalProfileDialog by mutableStateOf(false)
    private var pendingImportLocalProfileName by mutableStateOf<String?>(null)
    private var pendingImportLocalProfileUri by mutableStateOf<Uri?>(null)
    private var newProfileArgs by mutableStateOf(NewProfileArgs())
    private var parseImportLocalProfileJob: Job? = null
    private var pendingIntentErrorMessage by mutableStateOf<String?>(null)

    private val notificationPermissionLauncher =
        registerForActivityResult(
            ActivityResultContracts.RequestPermission(),
        ) {
            startService()
        }

    private val locationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) {
            if (it) {
                if (it && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    requestBackgroundLocationPermission()
                } else {
                    startService()
                }
            }
        }

    private val backgroundLocationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) {
            if (it) {
                startService()
            }
        }

    private val localNetworkPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) {
            startService()
        }

    private val prepareLauncher =
        registerForActivityResult(
            ActivityResultContracts.StartActivityForResult(),
        ) { result ->
            if (result.resultCode == RESULT_OK) {
                startService0()
            } else {
                onServiceAlert(Alert.RequestVPNPermission, null)
            }
        }
    private val pendingNavigationRoute = mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ConfigurationCompat.getLocales(resources.configuration)[0]?.let { locale ->
            runCatching {
                Libbox.setLocale(locale.toLanguageTag())
            }.onFailure {
                Log.d("MainActivity", "set locale: ${it.message}")
            }
        }
        enableEdgeToEdge()

        lifecycleScope.launch {
            Settings.dataStore.initialize()
            connection.reconnect()
            RemoteControlManager.restore()

            UpdateState.loadFromCache()
            if (Settings.checkUpdateEnabled) {
                lifecycleScope.launch(Dispatchers.IO) {
                    try {
                        val updateInfo = Vendor.checkUpdateAsync()
                        UpdateState.setUpdate(updateInfo)
                    } catch (_: Exception) {
                        UpdateState.setUpdate(null)
                    }
                }
            }

            handleIntent(intent)

            setContent {
                Theme {
                    App()
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent?) {
        if (intent == null) {
            return
        }
        if (intent.categories?.contains("de.robv.android.xposed.category.MODULE_SETTINGS") == true) {
            pendingNavigationRoute.value = "settings/privilege"
        }
        val uri = intent.data ?: return
        if (uri.scheme == "sing-box") {
            val target = if (uri.isOpaque) Uri.parse("sing-box://" + uri.schemeSpecificPart) else uri
            if (target.host == "taildrop") {
                val endpointTag = target.getQueryParameter("endpoint")
                if (!endpointTag.isNullOrEmpty()) {
                    pendingNavigationRoute.value = "tools/tailscale/${Uri.encode(endpointTag)}/taildrop"
                }
                return
            }
        }
        if (intent.action == Action.OPEN_URL) {
            launchCustomTab(uri.toString())
            return
        }
        if (uri.scheme == "sing-box" && uri.host == "import-remote-profile") {
            try {
                val profile = Libbox.parseRemoteProfileImportLink(uri.toString())
                pendingImportProfile = Triple(profile.name, profile.host, profile.url)
                showImportProfileDialog = true
            } catch (e: Exception) {
                pendingIntentErrorMessage = e.message ?: "Failed to parse profile link"
            }
            return
        }

        if (intent.action == Intent.ACTION_VIEW &&
            (uri.scheme == ContentResolver.SCHEME_CONTENT || uri.scheme == ContentResolver.SCHEME_FILE)
        ) {
            parseImportLocalProfileJob?.cancel()
            parseImportLocalProfileJob =
                lifecycleScope.launch(Dispatchers.IO) {
                    val importHandler = ProfileImportHandler(this@MainActivity)
                    when (val result = importHandler.parseUri(uri)) {
                        is ProfileImportHandler.UriParseResult.Success -> {
                            withContext(Dispatchers.Main) {
                                pendingImportLocalProfileName = result.name
                                pendingImportLocalProfileUri = uri
                                showImportLocalProfileDialog = true
                            }
                        }

                        is ProfileImportHandler.UriParseResult.Error -> {
                            withContext(Dispatchers.Main) {
                                pendingIntentErrorMessage = result.message
                            }
                        }
                    }
                }
        }
    }

    @SuppressLint("NewApi")
    fun startService() {
        lifecycleScope.launch {
            Settings.dataStore.initialize()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !ServiceNotification.checkPermission()) {
                if (!notificationPermissionRequested) {
                    notificationPermissionRequested = true
                    notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    return@launch
                }
                if (Settings.dynamicNotification) {
                    onServiceAlert(Alert.RequestNotificationPermission, null)
                    return@launch
                }
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.CINNAMON_BUN &&
                !hasPermission(Manifest.permission.ACCESS_LOCAL_NETWORK) &&
                !localNetworkPermissionRequested
            ) {
                localNetworkPermissionRequested = true
                if (ActivityCompat.shouldShowRequestPermissionRationale(this@MainActivity, Manifest.permission.ACCESS_LOCAL_NETWORK)) {
                    showLocalNetworkPermissionDialog = true
                } else {
                    localNetworkPermissionLauncher.launch(Manifest.permission.ACCESS_LOCAL_NETWORK)
                }
                return@launch
            }
            startService0()
        }
    }

    private fun startService0() {
        lifecycleScope.launch(Dispatchers.IO) {
            Settings.rebuildServiceMode()
            if (Settings.serviceMode == ServiceMode.VPN) {
                if (prepare()) {
                    return@launch
                }
            }
            val intent = Intent(Application.application, Settings.serviceClass())
            withContext(Dispatchers.Main) {
                ContextCompat.startForegroundService(this@MainActivity, intent)
            }
            Settings.startedByUser = true
        }
    }

    private suspend fun prepare() = withContext(Dispatchers.Main) {
        try {
            val intent = VpnService.prepare(this@MainActivity)
            if (intent != null) {
                prepareLauncher.launch(intent)
                true
            } else {
                false
            }
        } catch (e: Exception) {
            onServiceAlert(Alert.RequestVPNPermission, e.message)
            true
        }
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    fun App() {
        val navController = rememberNavController()
        val navBackStackEntry by navController.currentBackStackEntryAsState()
        val currentDestination = navBackStackEntry?.destination
        val currentRoute = currentDestination?.route
        val scope = rememberCoroutineScope()
        val importHandler = remember { ProfileImportHandler(this@MainActivity) }

        val windowSizeClass = currentWindowAdaptiveInfo().windowSizeClass
        val useNavigationRail =
            windowSizeClass.isWidthAtLeastBreakpointCompat(WindowSizeClassCompat.WIDTH_DP_MEDIUM_LOWER_BOUND)

        // Snackbar state
        val snackbarHostState = remember { SnackbarHostState() }
        // Error dialog state for UiEvent.ShowError
        var showErrorDialog by remember { mutableStateOf(false) }
        var errorMessage by remember { mutableStateOf("") }
        var pendingApplyServiceChangeMode by remember { mutableStateOf<UiEvent.ApplyServiceChange.Mode?>(null) }
        var activeApplyServiceChangeMode by remember { mutableStateOf<UiEvent.ApplyServiceChange.Mode?>(null) }
        var applyServiceChangeJob by remember { mutableStateOf<Job?>(null) }

        fun mergeApplyServiceChangeMode(
            current: UiEvent.ApplyServiceChange.Mode?,
            incoming: UiEvent.ApplyServiceChange.Mode,
        ): UiEvent.ApplyServiceChange.Mode = when {
            current == UiEvent.ApplyServiceChange.Mode.Restart ||
                incoming == UiEvent.ApplyServiceChange.Mode.Restart -> {
                UiEvent.ApplyServiceChange.Mode.Restart
            }

            else -> incoming
        }

        fun enqueueApplyServiceChange(mode: UiEvent.ApplyServiceChange.Mode) {
            if (currentServiceStatus != Status.Started) {
                return
            }

            pendingApplyServiceChangeMode = mergeApplyServiceChangeMode(pendingApplyServiceChangeMode, mode)

            val activeMode = activeApplyServiceChangeMode
            if (activeMode != null &&
                mergeApplyServiceChangeMode(activeMode, mode) != activeMode
            ) {
                snackbarHostState.currentSnackbarData?.dismiss()
            }

            if (applyServiceChangeJob?.isActive == true) {
                return
            }

            applyServiceChangeJob =
                scope.launch {
                    while (true) {
                        val modeToShow = pendingApplyServiceChangeMode ?: break
                        pendingApplyServiceChangeMode = null
                        activeApplyServiceChangeMode = modeToShow
                        val (message, actionLabel) =
                            when (modeToShow) {
                                UiEvent.ApplyServiceChange.Mode.Reload -> {
                                    getString(R.string.service_reload_required) to
                                        getString(R.string.action_reload)
                                }

                                UiEvent.ApplyServiceChange.Mode.Restart -> {
                                    getString(R.string.service_restart_required) to
                                        getString(R.string.action_restart)
                                }
                            }
                        val result =
                            snackbarHostState.showSnackbar(
                                message = message,
                                actionLabel = actionLabel,
                                duration = androidx.compose.material3.SnackbarDuration.Short,
                            )
                        activeApplyServiceChangeMode = null
                        if (result == androidx.compose.material3.SnackbarResult.ActionPerformed) {
                            try {
                                when (modeToShow) {
                                    UiEvent.ApplyServiceChange.Mode.Reload -> {
                                        withContext(Dispatchers.IO) {
                                            Libbox.newStandaloneCommandClient().serviceReload()
                                        }
                                    }

                                    UiEvent.ApplyServiceChange.Mode.Restart -> {
                                        restartServiceForApplyChange()
                                    }
                                }
                            } catch (e: Exception) {
                                errorMessage = e.message ?: e.toString()
                                showErrorDialog = true
                            }
                        }
                    }
                }
        }

        // Groups Sheet state
        var showGroupsSheet by remember { mutableStateOf(false) }

        // Connections Sheet state
        var showConnectionsSheet by remember { mutableStateOf(false) }

        // Error dialog state for UiEvent.ShowError
        val pendingIntentError = pendingIntentErrorMessage
        LaunchedEffect(pendingIntentError) {
            if (pendingIntentError != null) {
                errorMessage = pendingIntentError
                showErrorDialog = true
                pendingIntentErrorMessage = null
            }
        }
        val topBarState = remember { mutableStateOf(emptyList<TopBarEntry>()) }
        val topBarController = remember { TopBarController(topBarState) }
        val topBarOverride = topBarState.value.lastOrNull()?.content
        val openNewProfile: (NewProfileArgs) -> Unit = { args ->
            newProfileArgs = args
            navController.navigate(ProfileRoutes.NewProfile) {
                launchSingleTop = true
            }
        }

        // Handle service alerts
        currentAlert?.let { (alertType, message) ->
            ServiceAlertDialog(
                alertType = alertType,
                message = message,
                onDismiss = { currentAlert = null },
            )
        }

        // Handle UiEvent.ShowError dialog
        if (showErrorDialog) {
            SelectableMessageDialog(
                title = stringResource(R.string.error_title),
                message = errorMessage,
                onDismiss = { showErrorDialog = false },
            )
        }

        // Handle location permission dialogs
        if (showLocationPermissionDialog) {
            LocationPermissionDialog(onConfirm = {
                showLocationPermissionDialog = false
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    locationPermissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
                }
            }, onDismiss = { showLocationPermissionDialog = false })
        }

        if (showBackgroundLocationDialog) {
            BackgroundLocationPermissionDialog(onConfirm = {
                showBackgroundLocationDialog = false
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    backgroundLocationPermissionLauncher.launch(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
                }
            }, onDismiss = { showBackgroundLocationDialog = false })
        }

        if (showLocalNetworkPermissionDialog) {
            LocalNetworkPermissionDialog(onConfirm = {
                showLocalNetworkPermissionDialog = false
                localNetworkPermissionLauncher.launch(Manifest.permission.ACCESS_LOCAL_NETWORK)
            }, onDismiss = {
                showLocalNetworkPermissionDialog = false
                startService()
            })
        }

        // Handle import remote profile dialog
        if (showImportProfileDialog && pendingImportProfile != null) {
            val (name, host, url) = pendingImportProfile!!
            AlertDialog(
                onDismissRequest = {
                    showImportProfileDialog = false
                    pendingImportProfile = null
                },
                title = { Text(stringResource(R.string.import_remote_profile)) },
                text = { Text(stringResource(R.string.import_remote_profile_message, name, host)) },
                confirmButton = {
                    TextButton(onClick = {
                        openNewProfile(
                            NewProfileArgs(
                                importName = name,
                                importUrl = url,
                            ),
                        )
                        showImportProfileDialog = false
                        pendingImportProfile = null
                    }) {
                        Text(stringResource(R.string.ok))
                    }
                },
                dismissButton = {
                    TextButton(onClick = {
                        showImportProfileDialog = false
                        pendingImportProfile = null
                    }) {
                        Text(stringResource(android.R.string.cancel))
                    }
                },
            )
        }

        if (showImportLocalProfileDialog && pendingImportLocalProfileUri != null && pendingImportLocalProfileName != null) {
            val importName = pendingImportLocalProfileName!!
            val importUri = pendingImportLocalProfileUri!!
            AlertDialog(
                onDismissRequest = {
                    showImportLocalProfileDialog = false
                    pendingImportLocalProfileName = null
                    pendingImportLocalProfileUri = null
                },
                title = { Text(stringResource(R.string.import_profile_confirm_title)) },
                text = { Text(stringResource(R.string.import_profile_confirm_message, importName)) },
                confirmButton = {
                    TextButton(onClick = {
                        showImportLocalProfileDialog = false
                        pendingImportLocalProfileName = null
                        pendingImportLocalProfileUri = null
                        scope.launch {
                            when (val result = importHandler.importFromUri(importUri)) {
                                is ProfileImportHandler.ImportResult.Success -> {
                                    navController.navigate(ProfileRoutes.editProfile(result.profile.id)) {
                                        launchSingleTop = true
                                    }
                                }
                                is ProfileImportHandler.ImportResult.Error -> {
                                    errorMessage = result.message
                                    showErrorDialog = true
                                }
                            }
                        }
                    }) {
                        Text(stringResource(R.string.import_action))
                    }
                },
                dismissButton = {
                    TextButton(onClick = {
                        showImportLocalProfileDialog = false
                        pendingImportLocalProfileName = null
                        pendingImportLocalProfileUri = null
                    }) {
                        Text(stringResource(R.string.cancel))
                    }
                },
            )
        }

        // Handle update check prompt dialog (shown only once on first launch)
        var showUpdateCheckPrompt by remember { mutableStateOf(!Settings.updateCheckPrompted) }
        if (showUpdateCheckPrompt) {
            AlertDialog(
                onDismissRequest = {
                    Settings.updateCheckPrompted = true
                    showUpdateCheckPrompt = false
                },
                title = { Text(stringResource(R.string.check_update)) },
                text = {
                    MarkdownText(
                        markdown = stringResource(
                            if (BuildConfig.FLAVOR == "play") {
                                R.string.check_update_prompt_play
                            } else {
                                R.string.check_update_prompt_github
                            },
                        ),
                        style = MaterialTheme.typography.bodyMedium,
                    )
                },
                confirmButton = {
                    TextButton(onClick = {
                        Settings.updateCheckPrompted = true
                        Settings.checkUpdateEnabled = true
                        showUpdateCheckPrompt = false
                        scope.launch(Dispatchers.IO) {
                            try {
                                val result = Vendor.checkUpdateAsync()
                                UpdateState.setUpdate(result)
                            } catch (_: Exception) {
                                UpdateState.setUpdate(null)
                            }
                        }
                    }) {
                        Text(stringResource(R.string.ok))
                    }
                },
                dismissButton = {
                    TextButton(onClick = {
                        Settings.updateCheckPrompted = true
                        showUpdateCheckPrompt = false
                    }) {
                        Text(stringResource(R.string.no_thanks))
                    }
                },
            )
        }

        // Handle update available dialog
        val updateInfo by UpdateState.updateInfo
        val shouldShowUpdateDialog = updateInfo != null &&
            updateInfo!!.versionCode > Settings.lastShownUpdateVersion
        var showUpdateDialog by remember { mutableStateOf(true) }

        // Download dialog state
        var showDownloadDialog by remember { mutableStateOf(false) }
        var downloadJob by remember { mutableStateOf<Job?>(null) }
        var downloadError by remember { mutableStateOf<String?>(null) }

        if (showUpdateDialog && shouldShowUpdateDialog) {
            UpdateAvailableDialog(
                updateInfo = updateInfo!!,
                onDismiss = {
                    Settings.lastShownUpdateVersion = updateInfo!!.versionCode
                    showUpdateDialog = false
                },
                onUpdate = {
                    showDownloadDialog = true
                    downloadError = null
                    downloadJob = scope.launch {
                        try {
                            withContext(Dispatchers.IO) {
                                Vendor.downloadAndInstall(
                                    this@MainActivity,
                                    updateInfo!!.downloadUrl,
                                )
                            }
                            showDownloadDialog = false
                        } catch (e: Exception) {
                            downloadError = e.message
                        }
                    }
                },
            )
        }

        // Download progress dialog
        if (showDownloadDialog) {
            AlertDialog(
                onDismissRequest = {},
                title = { Text(stringResource(R.string.update)) },
                text = {
                    Column {
                        if (downloadError != null) {
                            Text(
                                downloadError!!,
                                color = MaterialTheme.colorScheme.error,
                            )
                        } else {
                            val progress by UpdateState.downloadProgress
                            val progressValue = progress
                            Column {
                                if (progressValue != null) {
                                    Text("${stringResource(R.string.downloading)} ${(progressValue * 100).toInt()}%")
                                } else {
                                    Text(stringResource(R.string.downloading))
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                if (progressValue != null) {
                                    LinearProgressIndicator(
                                        progress = { progressValue },
                                        modifier = Modifier.fillMaxWidth(),
                                    )
                                } else {
                                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(
                        onClick = {
                            downloadJob?.cancel()
                            downloadJob = null
                            showDownloadDialog = false
                            downloadError = null
                            UpdateState.downloadProgress.value = null
                        },
                    ) {
                        Text(stringResource(if (downloadError != null) R.string.ok else android.R.string.cancel))
                    }
                },
            )
        }

        val remoteServer by RemoteControlManager.remoteServer.collectAsState()
        val remoteConnected by RemoteControlManager.isConnected.collectAsState()
        val remoteStartedAt by RemoteControlManager.startedAt.collectAsState()
        val isRemote = remoteServer != null

        // Initialize the dashboard view model and store reference
        val dashboardViewModel: DashboardViewModel = viewModel()
        if (!::dashboardViewModel.isInitialized) {
            this.dashboardViewModel = dashboardViewModel
        }
        val dashboardUiState by dashboardViewModel.uiState.collectAsState()

        LaunchedEffect(currentServiceStatus) {
            dashboardViewModel.updateServiceStatus(currentServiceStatus)
        }

        if (dashboardUiState.showDeprecatedDialog && dashboardUiState.deprecatedNotes.isNotEmpty()) {
            val note = dashboardUiState.deprecatedNotes.first()
            AlertDialog(
                onDismissRequest = { },
                title = { Text(stringResource(R.string.error_deprecated_warning)) },
                text = { Text(note.message) },
                confirmButton = {
                    TextButton(onClick = { dashboardViewModel.dismissDeprecatedNote() }) {
                        Text(stringResource(R.string.ok))
                    }
                },
                dismissButton =
                if (!note.migrationLink.isNullOrBlank()) {
                    {
                        TextButton(onClick = {
                            dashboardViewModel.sendGlobalEvent(UiEvent.OpenUrl(note.migrationLink))
                            dashboardViewModel.dismissDeprecatedNote()
                        }) {
                            Text(stringResource(R.string.error_deprecated_documentation))
                        }
                    }
                } else {
                    null
                },
            )
        }

        val isSettingsSubScreen = currentRoute?.startsWith("settings/") == true
        val isToolsSubScreen = currentRoute?.startsWith("tools/") == true
        val isConnectionsDetail = currentRoute?.startsWith("connections/detail") == true
        val isProfileRoute = currentRoute?.startsWith("profile/") == true
        val currentRootRoute =
            when {
                isSettingsSubScreen -> Screen.Settings.route
                isToolsSubScreen -> Screen.Tools.route
                currentRoute?.startsWith(Screen.Connections.route) == true -> Screen.Connections.route
                currentRoute?.startsWith(Screen.Log.route) == true -> Screen.Log.route
                isProfileRoute -> Screen.Dashboard.route
                else -> currentRoute
            }
        val isConnectionsRoute = currentRootRoute == Screen.Connections.route
        val isGroupsRoute = currentRootRoute == Screen.Groups.route
        val isLogRoute = currentRootRoute == Screen.Log.route

        val isSubScreen = isSettingsSubScreen || isToolsSubScreen || isConnectionsDetail || isProfileRoute
        // Get LogViewModel instance if we're on the Log screen
        val logViewModel: LogViewModel? =
            if (isLogRoute) {
                viewModel()
            } else {
                null
            }

        val groupsViewModel: GroupsViewModel? =
            if (isGroupsRoute) {
                viewModel(
                    factory = object : ViewModelProvider.Factory {
                        override fun <T : ViewModel> create(modelClass: Class<T>): T {
                            @Suppress("UNCHECKED_CAST")
                            return GroupsViewModel(dashboardViewModel.commandClient) as T
                        }
                    },
                )
            } else {
                null
            }

        val connectionsViewModel: ConnectionsViewModel? =
            if (isConnectionsRoute) {
                viewModel()
            } else {
                null
            }

        val tailscaleSSHSharedViewModel: TailscaleSSHSharedViewModel = viewModel()

        val isToolsRoute = currentRootRoute == Screen.Tools.route

        val tailscaleStatusViewModel: TailscaleStatusViewModel = viewModel()
        val tailscaleState by tailscaleStatusViewModel.uiState.collectAsState()
        val taildropUnreadCount = tailscaleState.endpoints.sumOf { it.unreadFileCount }
        val taildropSendSessions by TaildropSendManager.sessions.collectAsState()
        val taildropFailedCount = taildropSendSessions.count { it.errorMessage != null }

        val usbIPStatusViewModel: USBIPStatusViewModel? =
            if (isToolsRoute) {
                viewModel()
            } else {
                null
            }

        val openConnectStatusViewModel: OpenConnectStatusViewModel? =
            if (isToolsRoute) {
                viewModel()
            } else {
                null
            }

        val openVPNStatusViewModel: OpenVPNStatusViewModel? =
            if (isToolsRoute) {
                viewModel()
            } else {
                null
            }

        val statusTargetActive = remoteServer != null || currentServiceStatus == Status.Started
        val subscribeStatus = {
            tailscaleStatusViewModel.subscribe()
            usbIPStatusViewModel?.subscribe()
            openConnectStatusViewModel?.subscribe()
            openVPNStatusViewModel?.subscribe()
        }
        val cancelStatus = {
            tailscaleStatusViewModel.cancel()
            usbIPStatusViewModel?.cancel()
            openConnectStatusViewModel?.cancel()
            openVPNStatusViewModel?.cancel()
        }
        LaunchedEffect(remoteServer?.id) {
            cancelStatus()
            if (statusTargetActive) {
                subscribeStatus()
            }
        }
        LaunchedEffect(
            statusTargetActive,
            usbIPStatusViewModel,
            openConnectStatusViewModel,
            openVPNStatusViewModel,
        ) {
            if (statusTargetActive) {
                subscribeStatus()
            } else {
                cancelStatus()
            }
        }
        val showGroupsInNav = dashboardUiState.hasGroups
        val connectionsAvailable = if (isRemote) remoteConnected else currentServiceStatus == Status.Started

        val railScreens =
            buildList {
                add(Screen.Dashboard)
                if (showGroupsInNav) {
                    add(Screen.Groups)
                }
                if (connectionsAvailable) {
                    add(Screen.Connections)
                }
                add(Screen.Log)
                add(Screen.Tools)
                add(Screen.Settings)
            }

        val allowedRoutes =
            buildSet {
                add(Screen.Dashboard.route)
                add(Screen.Log.route)
                add(Screen.Tools.route)
                add(Screen.Settings.route)
                if (useNavigationRail && showGroupsInNav) {
                    add(Screen.Groups.route)
                }
                if (useNavigationRail && connectionsAvailable) {
                    add(Screen.Connections.route)
                }
            }

        val pendingRoute = pendingNavigationRoute.value
        LaunchedEffect(pendingRoute) {
            if (pendingRoute != null) {
                navController.navigate(pendingRoute) {
                    launchSingleTop = true
                }
                pendingNavigationRoute.value = null
            }
        }

        LaunchedEffect(allowedRoutes, currentRootRoute, useNavigationRail) {
            if (currentRootRoute != null && !allowedRoutes.contains(currentRootRoute)) {
                navController.navigate(Screen.Dashboard.route) {
                    popUpTo(navController.graph.findStartDestination().id) {
                        saveState = true
                    }
                    launchSingleTop = true
                    restoreState = true
                }
            }
        }

        // Collect all UI events from GlobalEventBus
        LaunchedEffect(Unit) {
            GlobalEventBus.events.collect { event ->
                when (event) {
                    is UiEvent.ErrorMessage -> {
                        errorMessage = event.message
                        showErrorDialog = true
                    }

                    is UiEvent.OpenUrl -> {
                        this@MainActivity.launchCustomTab(event.url)
                    }

                    is UiEvent.RequestStartService -> {
                        startService()
                    }

                    is UiEvent.EditProfile -> {
                        navController.navigate(ProfileRoutes.editProfile(event.profileId)) {
                            launchSingleTop = true
                        }
                    }

                    is UiEvent.Navigate -> {
                        navController.navigate(event.route) {
                            launchSingleTop = true
                        }
                    }

                    is UiEvent.ApplyServiceChange -> enqueueApplyServiceChange(event.mode)
                }
            }
        }

        val topBarContent: @Composable () -> Unit = {
            topBarOverride?.invoke()
        }

        val scaffoldContent: @Composable (PaddingValues) -> Unit = { paddingValues ->
            CompositionLocalProvider(LocalScaffoldPadding provides paddingValues) {
                Box(
                    modifier = Modifier.fillMaxSize().consumeWindowInsets(paddingValues),
                ) {
                    // Service Status Bar (shown when service is running or stopping);
                    // remote control replaces it with the remote session bar.
                    val serviceRunning =
                        currentServiceStatus == Status.Started || currentServiceStatus == Status.Starting
                    val showStatusBar = isRemote || serviceRunning || currentServiceStatus == Status.Stopping
                    val showStartFab = !isRemote && !serviceRunning && dashboardUiState.selectedProfileId != -1L
                    val bottomOverlayPadding = paddingValues.calculateBottomPadding()

                    NavHost(
                        navController = navController,
                        serviceStatus = currentServiceStatus,
                        showStartFab = showStartFab,
                        showStatusBar = showStatusBar,
                        newProfileArgs = newProfileArgs,
                        onClearNewProfileArgs = { newProfileArgs = NewProfileArgs() },
                        onOpenNewProfile = openNewProfile,
                        dashboardViewModel = dashboardViewModel,
                        logViewModel = logViewModel,
                        groupsViewModel = groupsViewModel,
                        connectionsViewModel = connectionsViewModel,
                        tailscaleStatusViewModel = tailscaleStatusViewModel,
                        tailscaleSSHSharedViewModel = tailscaleSSHSharedViewModel,
                        usbIPStatusViewModel = usbIPStatusViewModel,
                        openConnectStatusViewModel = openConnectStatusViewModel,
                        openVPNStatusViewModel = openVPNStatusViewModel,
                        modifier = Modifier.fillMaxSize(),
                    )
                    if (!useNavigationRail) {
                        if (isRemote) {
                            RemoteStatusBar(
                                visible = !isSubScreen,
                                serverName = remoteServer?.displayName ?: "",
                                isConnected = remoteConnected,
                                startTime = remoteStartedAt,
                                groupsCount = dashboardUiState.groupsCount,
                                hasGroups = dashboardUiState.hasGroups,
                                onGroupsClick = { showGroupsSheet = true },
                                connectionsCount = dashboardUiState.connectionsCount,
                                onConnectionsClick = { showConnectionsSheet = true },
                                onDisconnectClick = { RemoteControlManager.exitRemoteControl() },
                                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = bottomOverlayPadding),
                            )
                        } else {
                            ServiceStatusBar(
                                visible = showStatusBar && !isSubScreen,
                                serviceStatus = currentServiceStatus,
                                startTime = dashboardUiState.serviceStartTime,
                                groupsCount = dashboardUiState.groupsCount,
                                hasGroups = dashboardUiState.hasGroups,
                                onGroupsClick = { showGroupsSheet = true },
                                connectionsCount = dashboardUiState.connectionsCount,
                                onConnectionsClick = { showConnectionsSheet = true },
                                onStopClick = { dashboardViewModel.toggleService() },
                                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = bottomOverlayPadding),
                            )
                        }
                    }

                    val showPadFab = useNavigationRail && !isSubScreen && (showStartFab || showStatusBar)
                    if (useNavigationRail) {
                        androidx.compose.animation.AnimatedVisibility(
                            visible = showPadFab,
                            enter = scaleIn(),
                            exit = scaleOut(),
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(bottom = bottomOverlayPadding)
                                .padding(20.dp),
                        ) {
                            val isRunning =
                                currentServiceStatus == Status.Started || currentServiceStatus == Status.Starting
                            val isStopping = currentServiceStatus == Status.Stopping
                            if (isRemote) {
                                ExtendedFloatingActionButton(
                                    onClick = { RemoteControlManager.exitRemoteControl() },
                                    icon = {
                                        Icon(
                                            imageVector = Icons.Default.LinkOff,
                                            contentDescription = stringResource(R.string.remote_disconnect),
                                        )
                                    },
                                    text = {
                                        if (remoteConnected && remoteStartedAt != null) {
                                            UptimeText(startTime = remoteStartedAt!!)
                                        } else {
                                            Text(
                                                text =
                                                if (remoteConnected) {
                                                    remoteServer?.displayName ?: ""
                                                } else {
                                                    stringResource(R.string.remote_connecting)
                                                },
                                                style = MaterialTheme.typography.labelLarge,
                                            )
                                        }
                                    },
                                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                                    contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                                    modifier = Modifier.height(64.dp),
                                )
                            } else if (currentServiceStatus == Status.Stopped) {
                                FloatingActionButton(
                                    onClick = { startService() },
                                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                                    contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.PlayArrow,
                                        contentDescription = stringResource(R.string.action_start),
                                    )
                                }
                            } else {
                                ExtendedFloatingActionButton(
                                    onClick = {
                                        if (isRunning || isStopping) {
                                            dashboardViewModel.toggleService()
                                        } else {
                                            startService()
                                        }
                                    },
                                    icon = {
                                        Icon(
                                            imageVector =
                                            if (isRunning || isStopping) {
                                                Icons.Default.Stop
                                            } else {
                                                Icons.Default.PlayArrow
                                            },
                                            contentDescription =
                                            if (isRunning || isStopping) {
                                                stringResource(R.string.stop)
                                            } else {
                                                stringResource(R.string.action_start)
                                            },
                                        )
                                    },
                                    text = {
                                        when {
                                            isRunning && dashboardUiState.serviceStartTime != null -> {
                                                UptimeText(startTime = dashboardUiState.serviceStartTime!!)
                                            }
                                            currentServiceStatus == Status.Started -> {
                                                Text(
                                                    text = stringResource(R.string.status_started),
                                                    style = MaterialTheme.typography.labelLarge,
                                                )
                                            }
                                            currentServiceStatus == Status.Starting -> {
                                                Text(
                                                    text = stringResource(R.string.status_starting),
                                                    style = MaterialTheme.typography.labelLarge,
                                                )
                                            }
                                            currentServiceStatus == Status.Stopping -> {
                                                Text(
                                                    text = stringResource(R.string.status_stopping),
                                                    style = MaterialTheme.typography.labelLarge,
                                                )
                                            }
                                            else -> {
                                                Text(
                                                    text = stringResource(R.string.action_start),
                                                    style = MaterialTheme.typography.labelLarge,
                                                )
                                            }
                                        }
                                    },
                                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                                    contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                                    modifier = Modifier.height(64.dp),
                                )
                            }
                        }
                    } else {
                        // Start FAB (shown when service is stopped and a profile is selected)
                        androidx.compose.animation.AnimatedVisibility(
                            visible = !isRemote &&
                                currentServiceStatus == Status.Stopped &&
                                dashboardUiState.selectedProfileId != -1L &&
                                !isSubScreen,
                            enter = scaleIn(),
                            exit = scaleOut(),
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(bottom = bottomOverlayPadding)
                                .padding(16.dp),
                        ) {
                            FloatingActionButton(
                                onClick = { startService() },
                                containerColor = MaterialTheme.colorScheme.primaryContainer,
                                contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PlayArrow,
                                    contentDescription = stringResource(R.string.action_start),
                                )
                            }
                        }
                    }
                }
            }
        }

        val crashReportUnreadCount by CrashReportManager.unreadCount.collectAsState()
        val oomReportUnreadCount by OOMReportManager.unreadCount.collectAsState()
        val powerReportUnreadCount by PowerReportManager.unreadCount.collectAsState()
        // The crash/OOM report entries are hidden in remote control mode.
        val toolsUnreadCount =
            (if (isRemote) 0 else crashReportUnreadCount + oomReportUnreadCount + powerReportUnreadCount) + taildropUnreadCount

        LaunchedEffect(Unit) {
            withContext(Dispatchers.IO) {
                CrashReportManager.refresh()
                OOMReportManager.refresh()
                PowerReportManager.refresh()
            }
        }

        CompositionLocalProvider(LocalTopBarController provides topBarController) {
            if (useNavigationRail) {
                Row(modifier = Modifier.fillMaxSize()) {
                    Surface(tonalElevation = 1.dp) {
                        NavigationRail(
                            modifier = Modifier.fillMaxHeight(),
                        ) {
                            val hasUpdate by UpdateState.hasUpdate
                            railScreens.forEach { screen ->
                                val selected = currentRootRoute == screen.route

                                NavigationRailItem(
                                    icon = {
                                        if (screen == Screen.Settings && hasUpdate) {
                                            BadgedBox(badge = { Badge(containerColor = MaterialTheme.colorScheme.primary) }) {
                                                Icon(screen.icon, contentDescription = null)
                                            }
                                        } else if (screen == Screen.Tools && taildropFailedCount > 0) {
                                            BadgedBox(badge = { Badge(containerColor = MaterialTheme.colorScheme.error) { Text("!") } }) {
                                                Icon(screen.icon, contentDescription = null)
                                            }
                                        } else if (screen == Screen.Tools && toolsUnreadCount > 0) {
                                            BadgedBox(badge = { Badge(containerColor = MaterialTheme.colorScheme.error) { Text("$toolsUnreadCount") } }) {
                                                Icon(screen.icon, contentDescription = null)
                                            }
                                        } else {
                                            Icon(screen.icon, contentDescription = null)
                                        }
                                    },
                                    label = { Text(stringResource(screen.titleRes)) },
                                    selected = selected,
                                    onClick = {
                                        navController.navigate(screen.route) {
                                            popUpTo(navController.graph.findStartDestination().id) {
                                                saveState = true
                                            }
                                            launchSingleTop = true
                                            restoreState = true
                                        }
                                    },
                                )
                            }
                        }
                    }

                    Scaffold(
                        modifier = Modifier
                            .weight(1f)
                            .consumeWindowInsets(WindowInsets.safeDrawing.only(WindowInsetsSides.Start)),
                        contentWindowInsets = ScaffoldDefaults.contentWindowInsets.exclude(
                            WindowInsets.safeDrawing.only(WindowInsetsSides.Start),
                        ),
                        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
                        topBar = topBarContent,
                    ) { paddingValues ->
                        scaffoldContent(paddingValues)
                    }
                }
            } else {
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
                    topBar = topBarContent,
                    bottomBar = {
                        if (!isSubScreen) {
                            val hasUpdate by UpdateState.hasUpdate
                            NavigationBar {
                                bottomNavigationScreens.forEach { screen ->
                                    NavigationBarItem(
                                        icon = {
                                            if (screen == Screen.Settings && hasUpdate) {
                                                BadgedBox(badge = { Badge(containerColor = MaterialTheme.colorScheme.primary) }) {
                                                    Icon(screen.icon, contentDescription = null)
                                                }
                                            } else if (screen == Screen.Tools && taildropFailedCount > 0) {
                                                BadgedBox(badge = { Badge(containerColor = MaterialTheme.colorScheme.error) { Text("!") } }) {
                                                    Icon(screen.icon, contentDescription = null)
                                                }
                                            } else if (screen == Screen.Tools && toolsUnreadCount > 0) {
                                                BadgedBox(badge = { Badge(containerColor = MaterialTheme.colorScheme.error) { Text("$toolsUnreadCount") } }) {
                                                    Icon(screen.icon, contentDescription = null)
                                                }
                                            } else {
                                                Icon(screen.icon, contentDescription = null)
                                            }
                                        },
                                        label = { Text(stringResource(screen.titleRes)) },
                                        selected =
                                        currentDestination?.hierarchy?.any {
                                            it.route == screen.route
                                        } == true,
                                        onClick = {
                                            navController.navigate(screen.route) {
                                                // Pop up to the start destination of the graph to
                                                // avoid building up a large stack of destinations
                                                popUpTo(navController.graph.findStartDestination().id) {
                                                    saveState = true
                                                }
                                                // Avoid multiple copies of the same destination
                                                launchSingleTop = true
                                                // Restore state when reselecting a previously selected item
                                                restoreState = true
                                            }
                                        },
                                    )
                                }
                            }
                        }
                    },
                ) { paddingValues ->
                    scaffoldContent(paddingValues)
                }
            }
        }

        LaunchedEffect(dashboardUiState.hasGroups) {
            if (!dashboardUiState.hasGroups) {
                showGroupsSheet = false
            }
        }
        LaunchedEffect(connectionsAvailable) {
            if (!connectionsAvailable) {
                showConnectionsSheet = false
            }
        }

        // Groups ModalBottomSheet
        if (showGroupsSheet && !useNavigationRail) {
            val groupsSheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
            val groupsViewModel: GroupsViewModel = viewModel(
                factory = object : ViewModelProvider.Factory {
                    override fun <T : ViewModel> create(modelClass: Class<T>): T {
                        @Suppress("UNCHECKED_CAST")
                        return GroupsViewModel(dashboardViewModel.commandClient) as T
                    }
                },
            )
            val groupsUiState by groupsViewModel.uiState.collectAsState()
            val allCollapsed = groupsUiState.expandedGroups.isEmpty()

            ModalBottomSheet(
                onDismissRequest = { showGroupsSheet = false },
                sheetState = groupsSheetState,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MaterialTheme.colorScheme.onSurface,
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .fillMaxHeight(),
                ) {
                    // Groups content
                    GroupsCard(
                        serviceStatus = currentServiceStatus,
                        commandClient = dashboardViewModel.commandClient,
                        viewModel = groupsViewModel,
                        listHeaderContent = {
                            Row(
                                modifier =
                                Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Text(
                                    text = stringResource(R.string.title_groups),
                                    style = MaterialTheme.typography.headlineSmall,
                                    fontWeight = FontWeight.Medium,
                                    color = MaterialTheme.colorScheme.onSurface,
                                )
                                if (groupsUiState.groups.isNotEmpty()) {
                                    IconButton(onClick = { groupsViewModel.toggleAllGroups() }) {
                                        Icon(
                                            imageVector = if (allCollapsed) {
                                                Icons.Default.UnfoldMore
                                            } else {
                                                Icons.Default.UnfoldLess
                                            },
                                            contentDescription = if (allCollapsed) {
                                                stringResource(R.string.expand_all)
                                            } else {
                                                stringResource(R.string.collapse_all)
                                            },
                                        )
                                    }
                                }
                            }
                        },
                        asSheet = true,
                        modifier = Modifier.fillMaxSize(),
                    )
                }
            }
        }

        // Connections ModalBottomSheet
        if (showConnectionsSheet && !useNavigationRail) {
            val connectionsSheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
            val connectionsViewModel: ConnectionsViewModel = viewModel()
            val connectionsUiState by connectionsViewModel.uiState.collectAsState()
            var selectedConnectionId by remember { mutableStateOf<String?>(null) }
            val selectedConnection = connectionsUiState.allConnections.find { it.id == selectedConnectionId }
            var cachedConnection by remember { mutableStateOf<Connection?>(null) }
            if (selectedConnection != null) {
                cachedConnection = selectedConnection
            } else if (selectedConnectionId != null && cachedConnection?.isActive == true) {
                cachedConnection = cachedConnection?.copy(closedAt = System.currentTimeMillis())
            }
            val displayConnection = if (selectedConnectionId != null) cachedConnection else null

            LaunchedEffect(Unit) {
                connectionsViewModel.setVisible(true)
            }

            DisposableEffect(Unit) {
                onDispose {
                    connectionsViewModel.setVisible(false)
                }
            }

            BackHandler(enabled = selectedConnectionId != null) {
                selectedConnectionId = null
            }

            ModalBottomSheet(
                onDismissRequest = {
                    showConnectionsSheet = false
                    selectedConnectionId = null
                },
                sheetState = connectionsSheetState,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MaterialTheme.colorScheme.onSurface,
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .fillMaxHeight(),
                ) {
                    if (displayConnection != null) {
                        ConnectionDetailsScreen(
                            connection = displayConnection,
                            onBack = { selectedConnectionId = null },
                            onClose = {
                                selectedConnectionId?.let { connectionsViewModel.closeConnection(it) }
                            },
                            asSheet = true,
                        )
                    } else {
                        ConnectionsPage(
                            serviceStatus = currentServiceStatus,
                            viewModel = connectionsViewModel,
                            asSheet = true,
                            showTitle = true,
                            onConnectionClick = { selectedConnectionId = it },
                            modifier = Modifier.fillMaxSize(),
                        )
                    }
                }
            }
        }
    }

    override fun onServiceStatusChanged(status: Status) {
        currentServiceStatus = status
    }

    fun reconnect() {
        connection.reconnect()
    }

    override fun onServiceAlert(type: Alert, message: String?) {
        when (type) {
            Alert.RequestLocationPermission -> {
                return requestLocationPermission()
            }

            else -> {
                currentAlert = Pair(type, message)
            }
        }
    }

    private fun requestLocationPermission() {
        if (!hasPermission(Manifest.permission.ACCESS_FINE_LOCATION)) {
            requestFineLocationPermission()
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            requestBackgroundLocationPermission()
        }
    }

    private fun requestFineLocationPermission() {
        // Show location permission dialog in Compose UI
        showLocationPermissionDialog = true
    }

    private fun requestBackgroundLocationPermission() {
        // Show background location permission dialog in Compose UI
        showBackgroundLocationDialog = true
    }

    private suspend fun restartServiceForApplyChange() {
        if (currentServiceStatus != Status.Started) {
            return
        }

        BoxService.stop()
        while (true) {
            when (currentServiceStatus) {
                Status.Stopped -> {
                    startService()
                    return
                }

                Status.Starting -> {
                    return
                }

                Status.Started, Status.Stopping -> {
                    delay(100L)
                }
            }
        }
    }

    override fun onDestroy() {
        connection.disconnect()
        super.onDestroy()
    }

    @Composable
    private fun ServiceAlertDialog(alertType: Alert, message: String?, onDismiss: () -> Unit) {
        val title =
            when (alertType) {
                Alert.RequestNotificationPermission -> stringResource(R.string.notification_permission_title)
                Alert.StartCommandServer -> stringResource(R.string.error_start_command_server)
                Alert.CreateService -> stringResource(R.string.error_create_service)
                Alert.StartService -> stringResource(R.string.error_start_service)
                else -> null
            }

        val dialogMessage =
            when (alertType) {
                Alert.RequestVPNPermission -> stringResource(R.string.error_missing_vpn_permission)
                Alert.RequestNotificationPermission -> stringResource(R.string.notification_permission_required_description)
                Alert.EmptyConfiguration -> stringResource(R.string.error_empty_configuration)
                else -> message
            }

        AlertDialog(
            onDismissRequest = onDismiss,
            title = title?.let { { Text(text = it) } },
            text = dialogMessage?.let { { Text(text = it) } },
            confirmButton = {
                TextButton(onClick = onDismiss) {
                    Text(stringResource(R.string.ok))
                }
            },
        )
    }

    @Composable
    private fun LocationPermissionDialog(onConfirm: () -> Unit, onDismiss: () -> Unit) {
        AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text(stringResource(R.string.location_permission_title)) },
            text = { Text(AnnotatedString.fromHtml(stringResource(R.string.location_permission_description))) },
            confirmButton = {
                TextButton(onClick = onConfirm) {
                    Text(stringResource(R.string.ok))
                }
            },
            dismissButton = {
                TextButton(onClick = onDismiss) {
                    Text(stringResource(R.string.no_thanks))
                }
            },
        )
    }

    @Composable
    private fun BackgroundLocationPermissionDialog(onConfirm: () -> Unit, onDismiss: () -> Unit) {
        AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text(stringResource(R.string.location_permission_title)) },
            text = { Text(AnnotatedString.fromHtml(stringResource(R.string.location_permission_background_description))) },
            confirmButton = {
                TextButton(onClick = onConfirm) {
                    Text(stringResource(R.string.ok))
                }
            },
            dismissButton = {
                TextButton(onClick = onDismiss) {
                    Text(stringResource(R.string.no_thanks))
                }
            },
        )
    }

    @Composable
    private fun LocalNetworkPermissionDialog(onConfirm: () -> Unit, onDismiss: () -> Unit) {
        AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text(stringResource(R.string.local_network_permission_title)) },
            text = { Text(stringResource(R.string.local_network_permission_description)) },
            confirmButton = {
                TextButton(onClick = onConfirm) {
                    Text(stringResource(R.string.ok))
                }
            },
            dismissButton = {
                TextButton(onClick = onDismiss) {
                    Text(stringResource(R.string.no_thanks))
                }
            },
        )
    }
}
